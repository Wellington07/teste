﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data; // DataTable
using System.Data.OleDb; // OleDbConnection
using System.Data.Common; // OleDataAdapter  DataTable

namespace teste
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

       

        protected void Button1_Click(object sender, EventArgs e)
        {
            String vSql;
            OleDbDataAdapter da = new OleDbDataAdapter();
            OleDbConnection Conn = new OleDbConnection("Data Source=.SQLEXPRESS;Initial Catalog=db_teste;Integrated Security=True;");
            Conn.Open();

            String nome, telefone, email, data;

            nome = TextBox2.Text;
            data = TextBox3.Text;
            email = TextBox4.Text;
            telefone = TextBox5.Text;

            vSql = "insert into cliente values( '" + nome + "', '" + data + "', '" + email + "', 'pessoal')";   //teste da conecão
            OleDbCommand cmdSql = new OleDbCommand(vSql, Conn);
            cmdSql.ExecuteNonQuery();
            Conn.Close();
        }
    }

}